GATE 2 EVIDENCE ARCHIVE — REVIEW REQUIRED
This is a sanitized index, NOT a copy of raw source evidence.
Source artifacts must be retained locally for independent verification.
Do not commit strategy modules, raw market data, SQLite databases, secrets or raw logs.
INCOMPLETE and SANDBOX claims are not empirical production PASS.
Test-run output and operator judgement must be supplied and reviewed separately.
